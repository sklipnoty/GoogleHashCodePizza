package domain;

/**
 * Google hashcode example
 * @author Sklipnoty
 */
public enum PizzaIngredient { T, M }
